import { ProjectIDUniqueValidatorDirective } from './project-idunique-validator.directive';

describe('ProjectIDUniqueValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new ProjectIDUniqueValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
