export class ClientLocation
{
    clientLocationID: number;
    clientLocationName: string;

    constructor()
    {
        this.clientLocationID = null;
        this.clientLocationName = null;
    }
}
