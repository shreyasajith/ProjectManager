import { ClientLocation } from './client-location';

describe('ClientLocation', () => {
  it('should create an instance', () => {
    expect(new ClientLocation()).toBeTruthy();
  });
});
